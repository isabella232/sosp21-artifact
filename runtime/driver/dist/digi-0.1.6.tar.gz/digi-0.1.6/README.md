# Programming driver

> TBD A dSpace driver is where automation logic resides. The driver takes a *view* as the input, executes a set of handlers that edit the view,  and writes the updated view as the output to the apiserver.  A view is a snapshot of the latest state of the digivice/lake's model taken upon the event that triggers the reconciliation. 
