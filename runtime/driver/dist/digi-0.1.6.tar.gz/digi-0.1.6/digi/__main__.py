"""
Driver entry point.
"""
import digi.main as main

if __name__ == '__main__':
    main.run()
